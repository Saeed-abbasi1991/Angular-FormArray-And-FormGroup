import { Component, OnInit, VERSION } from '@angular/core';
import {
  FormArray,
  FormControl,
  FormGroup,
  Validators,
  ReactiveFormsModule,
} from '@angular/forms';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit {
  passengers: passenger[];
  name = 'Angular ' + VERSION.major;

  form: FormGroup;
  constructor() {}
  ngOnInit() {}
  FillPassengers(): void {
    this.passengers = [];
    let passenger1 = new passenger();
    passenger1.name = 'ali';
    passenger1.tickets = [];
    let ticket1 = new ticket();
    ticket1.number = '11';
    ticket1.price = 1100000;
    ticket1.tax = 1000;

    let ticket2 = new ticket();
    ticket2.number = '12';
    ticket2.price = 1200000;
    ticket2.tax = 12000;

    passenger1.tickets.push(ticket1);
    passenger1.tickets.push(ticket2);
    this.passengers.push(passenger1);

    // let passenger2 = new passenger();
    // passenger2.name = 'saeed';
    // passenger2.tickets = [];
    // let ticket3 = new ticket();
    // ticket3.number = '21';
    // ticket3.price = 210000;
    // ticket3.tax = 21000;

    // let ticket4 = new ticket();
    // ticket4.number = '22';
    // ticket4.price = 220000;
    // ticket4.tax = 22000;

    // passenger2.tickets.push(ticket3);
    // passenger2.tickets.push(ticket4);
    // this.passengers.push(passenger2);

    if (this.form)
      if (this.form.controls) {
        this.form.reset();
      }
    this.form = new FormGroup({
      passengerformarray: new FormArray([]),
    });
    //alert(item.name);
    this.passengers[0].tickets.forEach((ticket) => {
      let ticketformgroup: FormGroup;
      ticketformgroup = new FormGroup({
        numbercontrol: new FormControl(ticket.number, Validators.required),
        pricecontrol: new FormControl(ticket.price, Validators.required),
        taxcontrol: new FormControl(ticket.tax),
      });
      (this.form.controls.passengerformarray as FormArray).controls.push(
        ticketformgroup
      );
    });
    debugger;
    alert(
      (
        (this.form.controls.passengerformarray as FormArray)
          .controls[0] as FormGroup
      ).controls.numbercontrol.value
    );
  }
  testvalues(): void {
    alert(this.passengers[0].tickets[0].number);
    alert(this.passengers[0].tickets[0].price);
    alert(this.passengers[0].tickets[1].number);
    alert(this.passengers[0].tickets[1].price);

    alert(
      (
        (this.form.controls.passengerformarray as FormArray)
          .controls[0] as FormGroup
      ).controls.numbercontrol.value
    );
    alert(
      (
        (this.form.controls.passengerformarray as FormArray)
          .controls[0] as FormGroup
      ).controls.pricecontrol.value
    );
    alert(
      (
        (this.form.controls.passengerformarray as FormArray)
          .controls[1] as FormGroup
      ).controls.numbercontrol.value
    );
    alert(
      (
        (this.form.controls.passengerformarray as FormArray)
          .controls[1] as FormGroup
      ).controls.pricecontrol.value
    );
  }
  NumberIsNotValid(ticketindex): boolean {
    return false;
  }
  PriceIsNotValid(ticketindex): boolean {
    return (
      this.form &&
      this.form.controls &&
      this.form.controls.passengerformarray &&
      (this.form.controls.passengerformarray as FormArray).controls &&
      (
        (this.form.controls.passengerformarray as FormArray).controls[
          ticketindex
        ] as FormGroup
      ).controls &&
      (
        (this.form.controls.passengerformarray as FormArray).controls[
          ticketindex
        ] as FormGroup
      ).controls.pricecontrol &&
      (
        (this.form.controls.passengerformarray as FormArray).controls[
          ticketindex
        ] as FormGroup
      ).controls.pricecontrol.touched &&
      (
        (this.form.controls.passengerformarray as FormArray).controls[
          ticketindex
        ] as FormGroup
      ).controls.pricecontrol.errors &&
      (
        (this.form.controls.passengerformarray as FormArray).controls[
          ticketindex
        ] as FormGroup
      ).controls.pricecontrol.errors.required
    );
  }
}
class passenger {
  name: string;
  tickets: ticket[];
}
class ticket {
  number: string;
  price: number;
  tax: number;
}
